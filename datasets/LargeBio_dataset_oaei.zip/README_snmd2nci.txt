SNOMED - NCI
----------------

- Reference UMLS-based mappings:
	Total mappings 18,844
	17,210 mappings "="
	1,634 mappings flagged with "?" (mapping involved in logical conflicts detected by Alcomo, LogMap and/or AML)

- SNOMED ontology (contains synonyms):
	- Big overlapping/module with FMA and NCI:    122,464 classes (40%) 
	- Small overlapping/module with NCI:  51,128 concepts (17%)

- NCI ontology (contains synonyms):
	- Whole ontology: 66,724 concepts
	- Small overlapping/module with SNMD:  23,958 concepts (36%)

